DuyNhatPoker — Private Texas Hold'em v1.1.1
=====================================
Chỉ sử dụng chip ảo. Không có thanh toán, nạp/rút tiền thật hay đổi thưởng.

CHẠY TRÊN WINDOWS
1. Cài Node.js LTS (https://nodejs.org/) nếu chưa có. Yêu cầu Node 18+.
2. Giải nén toàn bộ ZIP. Bấm START_WINDOWS.bat. Nếu trình duyệt mở trước khi máy chủ sẵn sàng, tải lại trang http://localhost:3000.
   Hoặc mở terminal trong thư mục và chạy: npm start
3. Nhập nickname, tạo phòng. Một nhóm dùng cùng máy chủ và cùng mã phòng.
4. Cùng mạng Wi-Fi: bạn bè mở http://<IP nội bộ máy chủ>:3000 (xem IPv4 bằng ipconfig). Cho phép Node qua firewall mạng riêng nếu cần.
5. Khác mạng: cần triển khai máy chủ Node.js lên hosting hỗ trợ tiến trình Node và HTTPS; lệnh chạy npm start, cổng do biến PORT của hosting cung cấp. Không dùng hosting chỉ phục vụ file tĩnh. Gửi URL công khai và mã phòng. Bản này chưa được triển khai công khai.

CÁCH CHƠI
- 2–9 người, mỗi người 10.000 chip ảo, blinds 50/100.
- Chủ phòng bắt đầu ván; tự động chia bài, đổi dealer, xử lý preflop/flop/turn/river/showdown.
- Fold, check, call, raise (nhập tổng cược của vòng), all-in; có pot phụ và chia chip khi hòa.
- Chủ phòng bấm chia ván mới; người hết chip được nhận 10.000 chip ảo khi ván kết thúc.
- Chat chữ, lịch sử thao tác, số ván, số ván thắng pot, VPIP (tự nguyện bỏ chip trước flop), lãi/lỗ chip từ các ván hoàn tất.
- Voice: bấm Voice ON, cấp quyền microphone; cần HTTPS hoặc localhost. Dùng WebRTC mesh và STUN công khai; nếu mạng chặn P2P có thể cần TURN (chưa tích hợp). Có thể tắt mic. Trình duyệt không hỗ trợ hoặc mạng hạn chế có thể không kết nối được. Voice chưa được thử thực tế trên nhiều thiết bị.

GIỚI HẠN BẢN 1.0
- Máy chủ giữ phòng trong RAM, dữ liệu mất khi khởi động lại. Phòng không hoạt động 24 giờ sẽ tự xóa.
- Phiên tham gia lưu trong trình duyệt. Thoát phòng trên giao diện không xóa ghế; mất phiên trình duyệt có thể phải tạo phòng mới. Chưa có chuyển host, kick, đồng hồ lượt hoặc tự fold khi mất kết nối. Không dành cho dịch vụ công cộng quy mô lớn.
- Chưa có tài khoản, cơ sở dữ liệu, bảo vệ chống spam nâng cao, TLS trực tiếp hay kiểm toán bảo mật. HTTPS do hosting cung cấp. Chỉ chia sẻ phòng với người quen.
- Mã nguồn thuần Node.js + HTML/CSS/JS, không cần cài thư viện npm.
- Chạy node test.js để kiểm tra bộ đánh giá bài và mô phỏng ván tự động.

PWA v1.1
- Deploy tren Render tu repository chua ma nguon (render.yaml ho tro Blueprint); hoac tao Node Web Service, build npm install, start npm start. Kiem tra dieu kien goi free truoc khi deploy.
- iPhone: mo URL HTTPS bang Safari, Chia se > Them vao man hinh chinh > Them.
- PWA can Internet; khong luu trang thai phong offline. Hosting ngu/khoi dong lai co the lam mat phong trong RAM.
- Chua co mat khau phong; ma phong va link chi nen chia se voi ban be.
