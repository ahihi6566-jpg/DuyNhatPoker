DuyNhatPoker v2.0.0 - virtual chips only
Update existing Render service: replace DuyNhatPoker_PWA_v1.1.1.zip in the root of the existing GitHub main branch with the provided ZIP (same filename, new internal version). Do not extract or rename it. Commit changes, then let Render auto-deploy or use Manual Deploy > Deploy latest commit. Existing build command: unzip -o DuyNhatPoker_PWA_v1.1.1.zip && npm install. Start command: npm start. Node >=18.
Host: create room, tap Setup, choose NLH or PLO4, blinds, ante, chip stack, timer, max seats, password, approvals, rebuy, auto deal. Settings and player management only between hands. Pause works during a hand; use pause when adjusting settings with auto-deal enabled. Initial chips apply to existing players before first hand, new players and rebuy thereafter. PLO uses exactly 2 hole cards and 3 board cards and enforces pot-limit raises. Timer checks if possible otherwise folds. Auto deal waits 5 seconds between hands when there has been recent room activity. Data stays in memory; deployment/restart wipes active rooms and stats. No real money. Voice and iOS browser behavior not tested on real devices; voice uses existing WebRTC STUN setup, no TURN relay. Tests are simulations, not certification of all poker edge cases.
Run npm test locally.

V2.1.0 — Blue Casino UI
- Responsive desktop and mobile (portrait/landscape), virtual chips only.
- Stylized card faces and patterned backs, deal/flip transitions, chip/pot pulse.
- Quick Bet/Raise presets (1/2, 2/3, Pot; 2X, 3X, 4X), slider, +/- and manual amount. Presets select only; confirm via Bet/Raise button. Targets clamped to legal min/max, including PLO limits.
- Existing host settings, Omaha/hold'em, chat, voice and statistics retained. Voice uses STUN/WebRTC as before; not guaranteed on all networks.
- Render: replace DuyNhatPoker_PWA_v1.1.1.zip in repository root, keep existing build and start commands. Data is in memory; deployment clears existing rooms.
- Test: npm test passed 160 simulated hands. Three browser contexts tested with a local HTTP API bridge, including preset selection persistence across polling, raise/call, Omaha switch, four cards, and PLO maximum. No JS errors during that test. Real Safari/iPhone and remote voice not tested.
