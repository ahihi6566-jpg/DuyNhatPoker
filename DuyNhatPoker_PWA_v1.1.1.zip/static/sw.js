// Online-only game; never cache room state or API responses.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.mode==='navigate')e.respondWith(fetch(e.request).catch(()=>new Response('<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>DuyNhatPoker</title><h2>DuyNhatPoker</h2><p>Can ket noi Internet de choi. Vui long thu lai.</p><button onclick=location.reload()>Thu lai</button>',{headers:{'Content-Type':'text/html; charset=utf-8'}})));});
