const assert=require('node:assert/strict');const{api,best,rooms}=require('./server');
assert.deepEqual(best(['As','2s','3s','4s','5s','Kd','Qh']),[8,5]);assert.deepEqual(best(['As','Ad','Ah','Ac','Kd','Qh','Js']),[7,14,13]);assert.deepEqual(best(['As','Ad','Ah','Kd','Kh','Qh','Js']),[6,14,13]);
for(let count of [2,3,6,9]){let host=api({op:'create',name:'P0'}),code=host.state.code,keys=new Map([[host.state.me,host.key]]);for(let i=1;i<count;i++){let a=api({op:'join',code,name:'P'+i});keys.set(a.state.me,a.key);}const send=(op,key=host.key,extra={})=>api({op,code,key,...extra}).state;for(let h=0;h<20;h++){let s=send('start');assert.equal(s.players.find(p=>p.id===s.me).hand.length,2);assert(s.players.filter(p=>p.id!==s.me).every(p=>p.hand.length===0));let n=0;while(s.phase!=='done'){assert(n++<150);let p=s.players.find(x=>x.id===s.turn),due=s.bet-p.bet;let type=due?'call':'check';if(h%4===1&&n===1&&s.players.filter(x=>x.inHand&&!x.folded).length>2)type='fold';if(h%4===2&&n===1&&p.stack+p.bet>s.bet)type='raise';if(h%4===3&&n===1)type='allin';s=send('action',keys.get(s.turn),{type,amount:Math.min(p.stack+p.bet,s.bet+s.minRaise)});}assert.equal(s.players.reduce((a,p)=>a+p.stack,0),count*10000+rooms.get(code).testRebuys*10000||count*10000);for(let p of s.players){if(p.stack===0){rooms.get(code).testRebuys=(rooms.get(code).testRebuys||0)+1;send('rebuy',keys.get(p.id));}}}}
console.log('PASS: hand rankings, private cards, betting rounds, folds, raises, all-in, chip conservation across 80 simulated hands.');
const {omahaBest,tick}=require('./server');
// Board-only royal flush is not a royal in Omaha; exactly 2 hole cards required.
assert.notDeepEqual(omahaBest(['2c','3d','4h','5c'],['As','Ks','Qs','Js','Ts']),[8,14]);
assert.deepEqual(omahaBest(['As','Ks','2d','3c'],['Qs','Js','Ts','4d','5c']),[8,14]);
for(const count of [2,3,6,9]){
 const h=api({op:'create',name:'Host'}),code=h.state.code,keys=new Map([[h.state.me,h.key]]),send=(op,key=h.key,extra={})=>api({op,code,key,...extra}).state;
 const cfg={...h.state.settings,variant:'omaha',starting:5000,sb:25,bb:50,ante:5,maxPlayers:count,timer:30,approval:true,password:'test',autoDeal:false,rebuy:true};
 send('settings',h.key,{settings:cfg});assert.throws(()=>api({op:'join',code,name:'Wrong'}),/Mật khẩu/);
 for(let i=1;i<count;i++){let a=api({op:'join',code,name:'P'+i,password:'test'});keys.set(a.state.me,a.key);assert(a.state.players.find(x=>x.id===a.state.me).awaiting);assert.throws(()=>send('settings',a.key,{settings:cfg}),/Chỉ chủ phòng/);send('manage',h.key,{type:'approve',target:a.state.me});}
 assert.throws(()=>api({op:'join',code,name:'Extra',password:'test'}),/đủ/);let expected=count*5000;
 for(let k=0;k<20;k++){
  let s=send('start');assert.equal(s.players.find(x=>x.id===s.me).hand.length,4);assert(s.players.filter(x=>x.id!==s.me).every(x=>x.hand.length===0));let n=0;
  while(s.phase!=='done'){
   assert(n++<200);let key=keys.get(s.turn),view=send('state',key),p=view.players.find(x=>x.id===view.me),due=view.bet-p.bet,max=view.maxTarget;
   let type=due?'call':'check',amount;
   if(n===1&&k%4===0){send('pause',h.key,{enabled:true});assert.throws(()=>send('action',key,{type}),/tạm dừng/);send('pause',h.key,{enabled:false});}
   if(n===1&&k%4===1&&max>view.bet&&p.stack+p.bet>max){assert.throws(()=>send('action',key,{type:'raise',amount:max+1}),/PLO/);}
   if(k%3===0&&n<=3&&view.canRaise&&max>=view.bet+view.minRaise){type='raise';amount=max;}
   if(k%3===1&&n===1)type='fold';
   if(k%3===2&&n===1&&p.stack+p.bet===max&&(max<=view.bet||view.canRaise))type='allin';
   s=send('action',key,{type,amount});
  }
  assert.equal(s.players.reduce((a,p)=>a+p.stack,0),expected);for(let p of s.players)if(p.stack===0){send('rebuy',keys.get(p.id));expected+=5000;}
 }
 let s=send('manage',h.key,{type:'chips',target:h.state.me,amount:20});assert.equal(s.players.reduce((a,p)=>a+p.stack,0),expected+20);send('resetStats');assert(send('state').players.every(p=>p.stats.hands===0));
}
{
 const h=api({op:'create',name:'Host'}),code=h.state.code,a=api({op:'join',name:'Guest',code}),send=(op,extra={})=>api({op,code,key:h.key,...extra}).state;
 send('settings',{settings:{...h.state.settings,autoDeal:true,timer:1}});let r=rooms.get(code);r.nextDeal=Date.now()-1;tick(r);assert.equal(r.phase,'preflop');let before=r.turn;tick(r,r.deadline+1);assert.notEqual(r.turn,before);if(r.phase==='done'){send('manage',{type:'kick',target:a.state.me});assert.throws(()=>api({op:'state',code,key:a.key}),/không tồn tại/);}
}
console.log('PASS: 80 Omaha hands, exact 2+3 ranking, pot limits, custom blinds/ante, password, host authorization, approval, pause, chip management, auto-deal and timer.');
